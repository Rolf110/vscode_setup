"""osi — a friendly YAML-driven wrapper over the osiris job launcher."""

from __future__ import annotations

__version__ = "0.1.0"

from .launcher import build_create_kwargs, launch, resolve
from .render import to_bash

__all__ = ["launch", "resolve", "to_bash", "build_create_kwargs", "__version__"]
