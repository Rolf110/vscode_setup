import sys
from pathlib import Path

# make the package importable without an install
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
