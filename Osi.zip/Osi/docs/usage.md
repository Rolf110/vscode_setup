# osi — usage

`osi` turns an awkward `osiris.create()` call into a YAML config. You describe a
job; osi fills defaults, evaluates dynamic values, composes the order-sensitive
`args` list, and submits.

```bash
pip install -e .          # from the repo root
osi launch train.yaml     # submit
osi show   train.yaml     # dry-run: resolved config + osiris kwargs, no submit
osi bash   train.yaml     # print the equivalent bash script
```

## Quickstart

Minimal config — only `name`, `image`, `pool`, `nodes`, `run.script` are
required (plus `envs` if you need them); everything else has a default:

```yaml
name: my-job
image: registry/img:latest
pool: my-pool
nodes: [node-0, node-1]
run:
  script: train.py
```

`osi show` shows what gets submitted (defaults applied): `command=python`,
`num_gpus=8`, `type=pytorchjob`, `restart=false`, `num_nodes=2` (= `len(nodes)`),
`script=""` (the osiris field stays empty; your path lives in `run.script`).

## Config schema

Top level maps onto `osiris.create()`:

| key | default | notes |
|-----|---------|-------|
| `name` | — | unique job name |
| `image` | — | container image |
| `pool` | — | compute pool |
| `nodes` | — | list of node names |
| `num_nodes` | `len(nodes)` | usually leave unset |
| `num_gpus` | `8` | GPUs per node |
| `type` | `pytorchjob` | |
| `restart` | `false` | |
| `script` | `""` | leave empty; real path is `run.script` |
| `timezone` | `UTC` | used by `${date:}`; also reads `$OSI_TZ` |
| `envs` | `{}` | env vars (values coerced to str) |
| `run` | — | the command block, below |

## The `run` block

```yaml
run:
  command: torchrun        # entrypoint (python, torchrun, full path, ...)
  launcher_args:           # flags for the launcher (torchrun opts)
    nproc_per_node: 8
  script: train.py         # the script path
  script_args:             # flags for your script
    path: /data/folder
    resume: true
  overrides:               # hydra-style overrides
    - data.batch_size=2
  dash_keys: false         # set true to turn _ into - in flag names
```

osi composes these into the osiris `args` list in order:
`[*launcher_args, script, *script_args, *overrides]`.

### Flattening rules (`launcher_args` and `script_args`)

A flag and its value are **separate tokens** (`--k v`, never `--k=v`):

- `path: /data` → `--path /data`
- `resume: true` → `--resume`; `resume: false` → omitted
- `tag: [a, b]` → `--tag a --tag b`
- give a raw list instead of a mapping to pass tokens verbatim:
  `launcher_args: ["--standalone"]`

`overrides` are emitted one element each and never split on `=`.

### torchrun defaults

When `command`'s basename is `torchrun`, osi injects launcher defaults
(matched on the basename, so `/opt/.../torchrun` works too):

```
--nnodes <num_nodes> --nproc_per_node <num_gpus> \
--node_rank $(RANK) \
--master_addr $(MASTER_ADDR).datalab.svc.cluster.local \
--master-port $(MASTER_PORT)
```

Override one key (`launcher_args: {nproc_per_node: 4}`), drop one
(`master-port: null`), or replace them all by giving a raw list.

## Eval engine

Two layers. Use the declarative resolvers for common cases; drop to `${py:}` for
anything else.

| resolver | example | result |
|----------|---------|--------|
| `uuid4` / `uuid4_short` | `${uuid4_short:5}` | `9ab3c` |
| `len` | `${len:nodes}` | `2` |
| `env` | `${env:HOME}` | env var |
| `date` | `${date:%Y-%m-%d}` | date in the predefined timezone |
| `stem` / `basename` | `${stem:ckpt_path}` | `epoch_1` / `epoch_1.ckpt` |
| `split` | `${split:${stem:ckpt_path},_,1}` | `1` |
| `replace` | `${replace:name,-,_}` | replaced string |
| `regex` | `${regex:'epoch_(\d+)',ckpt_path}` | first group |

A name-like argument (`nodes`, `ckpt_path`) is looked up as a config key; if it
isn't a key it's treated as a literal.

> **Regex:** quote the pattern (`'epoch_(\d+)'`) so OmegaConf passes it through.
> For anything non-trivial, prefer `${py:}`.

### `${py:...}` escape hatch

Arbitrary restricted Python, with sibling config values in scope:

```yaml
name: "train-${py:uuid4_short(5)}"
epoch: ${py:re_search(r'epoch_(\d+)', ckpt_path)}
tag:   "${py:'big' if len(nodes) > 4 else 'small'}"
```

Available: `uuid4`, `uuid4_short`, `len`, `str`, `int`, `float`, `range`,
`datetime`, `re_search`, `re_sub`, `stem`, `basename`, `Path`, plus your config
keys. No imports, no builtins, no dunders. The bare-brace form `{uuid4_short(5)}`
is accepted too and rewritten to `${py:...}`.

## Recipes

Dynamic name:

```yaml
name: "train-${py:uuid4_short(5)}"
```

Date-stamped run name (define once, reuse — guarantees the same value in the
name and the logger):

```yaml
timezone: Europe/Berlin
exp_date: ${date:}                 # 19-06-2026
name: "${exp_date}-exp"
run:
  overrides:
    - logger.run_name=${exp_date}
```

Epoch from a checkpoint path:

```yaml
ckpt_path: ".../epoch_1.ckpt"
epoch: ${split:${stem:ckpt_path},_,1}      # or ${py:re_search(r'epoch_(\d+)', ckpt_path)}
run:
  overrides:
    - logger.run_name=epoch-${epoch}
```

## Commands & overrides

```bash
osi launch CONFIG [--dry-run] [-v] [-q]
osi show   CONFIG
osi bash   CONFIG [--oneline] [--literal-placeholders] [--no-shebang]

# shared on all three:
--set KEY=VALUE     # repeatable, dotted keys, e.g. --set run.command=torchrun
--name TEXT         # shortcut override
--pool TEXT         # shortcut override
--defaults PATH     # extra defaults file
```

`osi launch` prints the dict returned by `osiris.create()` to stdout as JSON
(`-q` to silence). `--dry-run`/`-v` print the resolved config and the exact
kwargs without submitting.

`osi bash` translates k8s `$(VAR)` placeholders to bash `"${VAR}"` by default;
`--literal-placeholders` keeps them verbatim.

## Python API

```python
from osi import launch, resolve, to_bash

cfg  = resolve("train.yaml", overrides={"pool": "p2"})  # resolved+validated dict
sh   = to_bash("train.yaml")                            # bash script string
info = launch("train.yaml")                             # submit; osiris.create() dict
```
