"""Compose the flat osiris ``args`` list from the structured ``run`` block.

osiris wants a single order-sensitive list:

    [*launcher_args, script_path, *script_cmd_args, *overrides]

where a flag and its value are *separate* strings (``--k v``, never ``--k=v``)
and each hydra override is a single ``k=v`` element.

Internally we build *groups* — each group is the set of tokens that logically
belong together (``["--k", "v"]``, ``["--flag"]``, ``["k=v"]``).  ``compose_args``
flattens the groups for osiris; the bash renderer uses the groups to keep a flag
and its value on one line.  Both come from the same source, so they never drift.
"""

from __future__ import annotations

from typing import Any, Mapping

Group = list  # a list[str] of tokens that belong on one logical line


def _basename(command: str) -> str:
    return str(command).rsplit("/", 1)[-1]


def torchrun_defaults(num_nodes: Any, num_gpus: Any) -> dict:
    """Default launcher args for torchrun, tied to num_nodes / num_gpus."""
    return {
        "nnodes": num_nodes,
        "nproc_per_node": num_gpus,
        "node_rank": "$(RANK)",
        "master_addr": "$(MASTER_ADDR).datalab.svc.cluster.local",
        "master-port": "$(MASTER_PORT)",
    }


_LAUNCHER_DEFAULTS = {
    "torchrun": torchrun_defaults,
}


def _flag(key: str, dash_keys: bool) -> str:
    key = str(key)
    if dash_keys:
        key = key.replace("_", "-")
    return f"--{key}"


def flag_groups(value: Any, *, dash_keys: bool = False) -> list[Group]:
    """Group a ``launcher_args`` / ``script_args`` value into logical lines.

    * dict: ``k: v`` -> ``["--k", "v"]``; ``k: true`` -> ``["--k"]``;
      ``k: false``/``k: null`` -> omitted; ``k: [a, b]`` -> two groups.
    * list: passed through verbatim, one token per group.
    """
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return [[str(x)] for x in value]
    if not isinstance(value, Mapping):
        raise TypeError(
            f"launcher_args/script_args must be a mapping or list, got "
            f"{type(value).__name__}"
        )
    groups: list[Group] = []
    for key, val in value.items():
        if val is None or val is False:
            continue
        flag = _flag(key, dash_keys)
        if val is True:
            groups.append([flag])
        elif isinstance(val, (list, tuple)):
            for item in val:
                groups.append([flag, str(item)])
        else:
            groups.append([flag, str(val)])
    return groups


def launcher_groups(
    command: str,
    launcher_args: Any,
    num_nodes: Any,
    num_gpus: Any,
    *,
    dash_keys: bool = False,
) -> list[Group]:
    """Merge command-aware defaults with the user's launcher_args, then group.

    A raw list replaces the defaults entirely; a dict merges over them (user
    keys win, ``null`` drops a default).
    """
    factory = _LAUNCHER_DEFAULTS.get(_basename(command))
    if factory is None or isinstance(launcher_args, (list, tuple)):
        return flag_groups(launcher_args, dash_keys=dash_keys)

    defaults = factory(num_nodes, num_gpus)
    user = dict(launcher_args) if isinstance(launcher_args, Mapping) else {}
    merged = {**defaults, **user}  # user overrides; preserves default ordering
    return flag_groups(merged, dash_keys=dash_keys)


def compose_groups(
    run: Mapping[str, Any],
    *,
    num_nodes: Any,
    num_gpus: Any,
) -> list[Group]:
    """Build the ordered logical groups for the osiris ``args`` list."""
    command = run.get("command", "python")
    dash_keys = bool(run.get("dash_keys", False))
    script = run.get("script")

    groups: list[Group] = []
    groups += launcher_groups(
        command, run.get("launcher_args"), num_nodes, num_gpus, dash_keys=dash_keys
    )
    if script is not None and str(script) != "":
        groups.append([str(script)])
    groups += flag_groups(run.get("script_args"), dash_keys=dash_keys)
    groups += [[str(o)] for o in (run.get("overrides") or [])]
    return groups


def compose_args(
    run: Mapping[str, Any],
    *,
    num_nodes: Any,
    num_gpus: Any,
) -> list[str]:
    """Flatten the groups into the osiris ``args`` list."""
    return [tok for grp in compose_groups(run, num_nodes=num_nodes, num_gpus=num_gpus) for tok in grp]
