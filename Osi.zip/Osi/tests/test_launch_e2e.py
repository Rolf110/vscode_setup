import sys
import types

from osi.launcher import build_create_kwargs, launch, resolve


def _stub_osiris(monkeypatch):
    captured = {}

    def create(**kwargs):
        captured.update(kwargs)
        return {"status": "submitted", "name": kwargs["name"]}

    mod = types.ModuleType("osiris")
    mod.create = create
    monkeypatch.setitem(sys.modules, "osiris", mod)
    return captured


CFG = {
    "name": "train-x", "image": "img", "pool": "pool", "nodes": ["a", "b"],
    "envs": {"PYTHONPATH": "/venv"},
    "run": {"command": "torchrun", "launcher_args": {"nproc_per_node": 8},
            "script": "train.py", "script_args": {"path": "/d"},
            "overrides": ["data.batch_size=2"]},
}


def test_launch_returns_osiris_dict_unchanged(monkeypatch):
    captured = _stub_osiris(monkeypatch)
    info = launch(dict(CFG))
    assert info == {"status": "submitted", "name": "train-x"}
    # the exact kwargs we composed reached osiris.create
    assert captured["command"] == "torchrun"
    assert captured["script"] == ""
    assert captured["num_nodes"] == 2
    assert captured["args"][0:2] == ["--nnodes", "2"]
    assert "train.py" in captured["args"]


def test_build_kwargs_maps_all_osiris_fields():
    kw = build_create_kwargs(resolve(dict(CFG)))
    expected = {"name", "image", "script", "command", "restart", "pool",
                "nodes", "num_nodes", "num_gpus", "type", "envs", "args"}
    assert set(kw) == expected
