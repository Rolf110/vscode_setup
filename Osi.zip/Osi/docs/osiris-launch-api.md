# Osiris — Initial Job Launching API (reference)

This is the raw `osiris` API that `osi` wraps. Captured as ground truth so the
wrapper stays faithful to the underlying behavior.

## `osiris.create(**kwargs) -> dict`

Submits a remote job and returns a dict with job info.

### Arguments

| # | Arg | Type | Required | Default (typical) | Notes |
|---|-----|------|----------|-------------------|-------|
| 1 | `name` | `str` | yes | — | Unique job name, e.g. `"train-u12jk"`. Usually generated as `f"train-{str(uuid4())[:5]}"`. Internally osiris rewrites it to `f"training-23278165-pytorchjob-{name}"`. |
| 2 | `image` | `str` | yes | — | Container image to run. |
| 3 | `script` | `str` | yes | `""` | Usually empty. The actual script path is passed inside `args`, **not** here. |
| 4 | `command` | `str` | yes | — | Entrypoint, e.g. `"python"`, `"torchrun"`. |
| 5 | `restart` | `bool` | no | `False` | Whether the job restarts on failure. |
| 6 | `pool` | `str` | yes | — | Target compute pool. |
| 7 | `nodes` | `list[str]` | yes | — | Explicit node list. |
| 8 | `num_nodes` | `int` | yes | `len(nodes)` | Almost always `len(nodes)`. |
| 9 | `num_gpus` | `int` | yes | `8` | GPUs per node, usually 8. |
| 10 | `type` | `str` | yes | `"pytorchjob"` | Job type. |
| 11 | `envs` | `dict[str, str]` | yes | — | Env vars, e.g. `{"PYTHONPATH": "/path/to/venv", ...}`. |
| 12 | `args` | `list[str]` | yes | — | Command args **and** the script path. See schema below. |

### `args` list schema

`args` is a single flat `list[str]` combining three segments **in order**:

```
[ *args_for_torchrun_if_any, script_path, *script_cmd_args ]
```

1. **Launcher args** (optional) — flags consumed by `command` itself (e.g.
   torchrun options). Empty when `command` is plain `python`. A flag and its
   value are **separate list elements** (`["--nproc_per_node", "8"]`), same as
   conventional script flags — not a single `--nproc_per_node=8` token.
2. **`script_path`** — the path to the script to run. Passed here, **not** in the
   `script` arg.
3. **`script_cmd_args`** — arguments forwarded to the script. Two flavors, which
   may be mixed:
   - **Conventional flags**: each token is its own list element.
     `--path /folder` → `["--path", "/folder"]`
   - **Hydra config overrides**: each override is one whole list element
     (no splitting on `=`).
     `data.batch_size=2` → `["data.batch_size=2"]`

### Examples

Plain python, conventional flag:
```python
osiris.create(
    name="train-u12jk",
    image="registry/img:latest",
    script="",
    command="python",
    restart=False,
    pool="my-pool",
    nodes=["node-0", "node-1"],
    num_nodes=2,            # == len(nodes)
    num_gpus=8,
    type="pytorchjob",
    envs={"PYTHONPATH": "/path/to/venv"},
    args=["train.py", "--path", "/data/folder"],
)
```

torchrun + hydra overrides:
```python
osiris.create(
    name="train-9ab3c",
    image="registry/img:latest",
    script="",
    command="torchrun",
    restart=False,
    pool="my-pool",
    nodes=["node-0", "node-1"],
    num_nodes=2,
    num_gpus=8,
    type="pytorchjob",
    envs={"PYTHONPATH": "/path/to/venv"},
    args=[
        "--nproc_per_node", "8",  # launcher arg for torchrun (separate strings)
        "train.py",               # script_path
        "data.batch_size=2",      # hydra override (one element)
        "trainer.max_steps=1000", # hydra override (one element)
    ],
)
```

### Pain points `osi` should fix

- The flat, order-sensitive `args` list is error-prone — easy to misplace the
  script path or split a hydra override.
- Boilerplate repeated on every call (`script=""`, `type="pytorchjob"`,
  `num_gpus=8`, `restart=False`).
- `num_nodes` is manually kept in sync with `nodes`.
- No declarative/reproducible spec — everything lives in throwaway Python.
- Dynamic values (unique names, etc.) are hand-rolled each time.
