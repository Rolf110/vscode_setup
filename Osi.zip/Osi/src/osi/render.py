"""Render a resolved config into an equivalent bash invocation string."""

from __future__ import annotations

import re
import shlex
from pathlib import Path
from typing import Any, Iterable, Mapping

from . import args_builder
from .launcher import resolve

# k8s-style $(VAR) -> bash ${VAR}
_K8S_VAR = re.compile(r"\$\((\w+)\)")


def _quote(token: str, *, literal_placeholders: bool) -> str:
    """Shell-quote a token, translating $(VAR) to an expandable "${VAR}"."""
    if not literal_placeholders and _K8S_VAR.search(token):
        translated = _K8S_VAR.sub(r"${\1}", token)
        # keep ${VAR} expandable -> double quotes, escape embedded " and \
        escaped = translated.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'
    return shlex.quote(token)


def to_bash(
    config: Any,
    *,
    overrides: Mapping[str, Any] | None = None,
    set_list: Iterable[str] | None = None,
    defaults_path: str | Path | None = None,
    oneline: bool = False,
    literal_placeholders: bool = False,
    shebang: bool = True,
) -> str:
    """Build the equivalent shell script string for a config (no file written)."""
    resolved = resolve(
        config, overrides=overrides, set_list=set_list, defaults_path=defaults_path
    )
    run = resolved["run"]
    command = run.get("command", "python")
    groups = args_builder.compose_groups(
        run, num_nodes=resolved["num_nodes"], num_gpus=resolved["num_gpus"]
    )

    lines: list[str] = []
    if shebang:
        lines.append("#!/usr/bin/env bash")
    for key, val in (resolved.get("envs") or {}).items():
        lines.append(f"export {key}={shlex.quote(str(val))}")

    if oneline:
        flat = [shlex.quote(command)] + [
            _quote(str(t), literal_placeholders=literal_placeholders)
            for g in groups for t in g
        ]
        lines.append(" ".join(flat))
    else:
        # command on the first line, each logical group on its own continued line
        body_lines = [shlex.quote(command)]
        for g in groups:
            body_lines.append(
                " ".join(
                    _quote(str(t), literal_placeholders=literal_placeholders) for t in g
                )
            )
        lines.append(" \\\n  ".join(body_lines))

    return "\n".join(lines) + "\n"
