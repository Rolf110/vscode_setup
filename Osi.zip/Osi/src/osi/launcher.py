"""Map a resolved config onto ``osiris.create()`` and submit."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable, Mapping

from . import args_builder
from .config import resolve_config
from .schema import validate


def resolve(
    config: Any,
    *,
    overrides: Mapping[str, Any] | None = None,
    set_list: Iterable[str] | None = None,
    defaults_path: str | Path | None = None,
) -> dict:
    """Load + layer + resolve + validate a config into a plain dict (dry-run)."""
    resolved = resolve_config(
        config, overrides=overrides, set_list=set_list, defaults_path=defaults_path
    )
    return validate(resolved)


def build_create_kwargs(resolved: Mapping[str, Any]) -> dict:
    """Map a validated config onto the exact osiris.create() keyword args."""
    run = resolved["run"]
    args = args_builder.compose_args(
        run, num_nodes=resolved["num_nodes"], num_gpus=resolved["num_gpus"]
    )
    return {
        "name": resolved["name"],
        "image": resolved["image"],
        "script": resolved.get("script", ""),
        "command": run.get("command", "python"),
        "restart": resolved.get("restart", False),
        "pool": resolved["pool"],
        "nodes": resolved["nodes"],
        "num_nodes": resolved["num_nodes"],
        "num_gpus": resolved["num_gpus"],
        "type": resolved.get("type", "pytorchjob"),
        "envs": resolved.get("envs", {}),
        "args": args,
    }


def submit(kwargs: Mapping[str, Any]) -> dict:
    """Call ``osiris.create(**kwargs)`` and return its dict unchanged.

    osiris is imported lazily so resolve()/to_bash() work without it installed.
    """
    import osiris

    return osiris.create(**dict(kwargs))


def launch(
    config: Any,
    *,
    overrides: Mapping[str, Any] | None = None,
    set_list: Iterable[str] | None = None,
    defaults_path: str | Path | None = None,
) -> dict:
    """Resolve, validate, and submit the job. Returns the osiris.create() dict.

    Resolves exactly once, so dynamic values (``${uuid4}``, ``${date}``) in the
    submitted job match what a prior ``resolve()`` of the same object produced.
    """
    resolved = resolve(
        config, overrides=overrides, set_list=set_list, defaults_path=defaults_path
    )
    return submit(build_create_kwargs(resolved))
