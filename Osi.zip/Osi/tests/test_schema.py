import warnings

import pytest
from pydantic import ValidationError

from osi.config import resolve_config
from osi.launcher import resolve
from osi.schema import validate


GOOD = {"name": "n", "image": "i", "pool": "p", "nodes": ["a", "b"],
        "run": {"script": "t.py"}}


def test_valid_config_passes():
    out = resolve(dict(GOOD))
    assert out["name"] == "n"


def test_missing_required_name():
    cfg = resolve_config({k: v for k, v in GOOD.items() if k != "name"})
    with pytest.raises(ValidationError):
        validate(cfg)


def test_empty_nodes_rejected():
    cfg = resolve_config({**GOOD, "nodes": [], "num_nodes": 1})
    with pytest.raises(ValidationError):
        validate(cfg)


def test_missing_script_rejected():
    cfg = resolve_config({**GOOD, "run": {"command": "python"}})
    with pytest.raises(ValidationError):
        validate(cfg)


def test_num_gpus_must_be_positive():
    cfg = resolve_config({**GOOD, "num_gpus": 0})
    with pytest.raises(ValidationError):
        validate(cfg)


def test_envs_coerced_to_str():
    cfg = resolve_config({**GOOD, "envs": {"RANK": 0, "DEBUG": True}})
    out = validate(cfg)
    assert out["envs"] == {"RANK": "0", "DEBUG": "True"}


def test_num_nodes_mismatch_warns():
    cfg = resolve_config({**GOOD, "num_nodes": 9})
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        validate(cfg)
    assert any("num_nodes" in str(x.message) for x in w)


def test_extra_keys_allowed():
    out = resolve(dict(ckpt_path="/x/e.ckpt", **GOOD))
    assert out["ckpt_path"] == "/x/e.ckpt"
