from osi.render import to_bash


BASE = {
    "name": "n", "image": "i", "pool": "p", "nodes": ["node-0", "node-1"],
    "envs": {"PYTHONPATH": "/venv"},
    "run": {
        "command": "torchrun",
        "launcher_args": {"nproc_per_node": 8},
        "script": "train.py",
        "script_args": {"path": "/data/folder", "resume": True},
        "overrides": ["data.batch_size=2"],
    },
}


def test_shebang_and_env_export():
    sh = to_bash(dict(BASE))
    assert sh.startswith("#!/usr/bin/env bash\n")
    assert "export PYTHONPATH=/venv" in sh


def test_k8s_placeholder_translated_to_bash_var():
    sh = to_bash(dict(BASE))
    assert '"${RANK}"' in sh
    assert '"${MASTER_ADDR}.datalab.svc.cluster.local"' in sh
    assert "$(RANK)" not in sh


def test_literal_placeholders_kept():
    sh = to_bash(dict(BASE), literal_placeholders=True)
    assert "$(RANK)" in sh
    assert "${RANK}" not in sh


def test_flag_and_value_on_same_line():
    sh = to_bash(dict(BASE))
    assert "--nproc_per_node 8" in sh
    assert "--path /data/folder" in sh or "--path '/data/folder'" in sh


def test_oneline_has_no_continuations():
    sh = to_bash(dict(BASE), oneline=True)
    assert "\\\n" not in sh
    assert "torchrun --nnodes 2" in sh


def test_no_shebang_option():
    sh = to_bash(dict(BASE), shebang=False)
    assert not sh.startswith("#!")
