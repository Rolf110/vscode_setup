"""Click CLI: ``osi launch`` / ``osi show`` / ``osi bash``."""

from __future__ import annotations

import json
import sys

import click
import yaml

from . import __version__
from .launcher import build_create_kwargs, resolve as _resolve, submit as _submit
from .render import to_bash as _to_bash


def _overrides(name, pool):
    ov = {}
    if name:
        ov["name"] = name
    if pool:
        ov["pool"] = pool
    return ov or None


def common_options(f):
    f = click.argument("config", type=click.Path(exists=True, dir_okay=False))(f)
    f = click.option(
        "--set", "set_", multiple=True, metavar="KEY=VALUE",
        help="Override any config key (repeatable, dotted keys).",
    )(f)
    f = click.option("--name", default=None, help="Shortcut override for name.")(f)
    f = click.option("--pool", default=None, help="Shortcut override for pool.")(f)
    f = click.option(
        "--defaults", "defaults_path", type=click.Path(exists=True, dir_okay=False),
        default=None, help="Extra defaults file (layer 2).",
    )(f)
    return f


@click.group()
@click.version_option(version=__version__, prog_name="osi")
def main():
    """osi — friendly YAML-driven wrapper over osiris."""


def _resolved(config, set_, name, pool, defaults_path):
    return _resolve(
        config, overrides=_overrides(name, pool),
        set_list=set_, defaults_path=defaults_path,
    )


@main.command()
@common_options
@click.option("--dry-run", is_flag=True, help="Resolve + print, do NOT submit.")
@click.option("-v", "--verbose", is_flag=True, help="Print resolved cfg before submit.")
@click.option("-q", "--quiet", is_flag=True, help="Don't print the returned osiris dict.")
def launch(config, set_, name, pool, defaults_path, dry_run, verbose, quiet):
    """Resolve, validate, and submit a job."""
    try:
        resolved = _resolved(config, set_, name, pool, defaults_path)
        kwargs = build_create_kwargs(resolved)
    except Exception as ex:
        raise click.ClickException(str(ex))

    if dry_run or verbose:
        click.echo("# resolved config", err=True)
        click.echo(yaml.safe_dump(resolved, sort_keys=False), err=True)
        click.echo("# osiris.create() kwargs", err=True)
        click.echo(json.dumps(kwargs, indent=2, default=str), err=True)
    if dry_run:
        return

    try:
        info = _submit(kwargs)
    except Exception as ex:
        raise click.ClickException(str(ex))
    if not quiet:
        click.echo(json.dumps(info, indent=2, default=str))


@main.command()
@common_options
def show(config, set_, name, pool, defaults_path):
    """Dry-run: resolve + validate, print config and osiris.create() kwargs."""
    try:
        resolved = _resolved(config, set_, name, pool, defaults_path)
        kwargs = build_create_kwargs(resolved)
    except Exception as ex:
        raise click.ClickException(str(ex))
    click.echo("# resolved config")
    click.echo(yaml.safe_dump(resolved, sort_keys=False))
    click.echo("# osiris.create() kwargs")
    click.echo(json.dumps(kwargs, indent=2, default=str))


@main.command()
@common_options
@click.option("--oneline", is_flag=True, help="Emit a single-line command.")
@click.option("--literal-placeholders", is_flag=True, help="Keep $(VAR) verbatim.")
@click.option("--no-shebang", is_flag=True, help="Omit the #!/usr/bin/env bash line.")
def bash(config, set_, name, pool, defaults_path, oneline, literal_placeholders, no_shebang):
    """Print the equivalent bash script string to stdout."""
    try:
        script = _to_bash(
            config, overrides=_overrides(name, pool), set_list=set_,
            defaults_path=defaults_path, oneline=oneline,
            literal_placeholders=literal_placeholders, shebang=not no_shebang,
        )
    except Exception as ex:
        raise click.ClickException(str(ex))
    click.echo(script, nl=False)


if __name__ == "__main__":
    main()
