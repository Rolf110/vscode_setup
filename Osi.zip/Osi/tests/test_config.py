from osi.config import resolve_config


BASE = {"name": "n", "image": "i", "pool": "p", "nodes": ["a", "b"],
        "run": {"script": "t.py"}}


def test_builtin_defaults_applied():
    cfg = resolve_config(dict(BASE))
    assert cfg["num_gpus"] == 8
    assert cfg["type"] == "pytorchjob"
    assert cfg["restart"] is False
    assert cfg["script"] == ""
    assert cfg["run"]["command"] == "python"


def test_job_overrides_defaults():
    cfg = resolve_config({**BASE, "num_gpus": 4, "type": "mpijob"})
    assert cfg["num_gpus"] == 4
    assert cfg["type"] == "mpijob"


def test_overrides_mapping_wins():
    cfg = resolve_config(dict(BASE), overrides={"pool": "other"})
    assert cfg["pool"] == "other"


def test_set_dotlist_nested_and_coerced():
    cfg = resolve_config(dict(BASE), set_list=["num_gpus=2", "run.command=torchrun"])
    assert cfg["num_gpus"] == 2 and isinstance(cfg["num_gpus"], int)
    assert cfg["run"]["command"] == "torchrun"


def test_set_precedence_over_job():
    cfg = resolve_config({**BASE, "num_gpus": 4}, set_list=["num_gpus=1"])
    assert cfg["num_gpus"] == 1


def test_explicit_num_nodes_kept():
    cfg = resolve_config({**BASE, "num_nodes": 5})
    assert cfg["num_nodes"] == 5
