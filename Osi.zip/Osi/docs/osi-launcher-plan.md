# osi — Job Launcher (design plan)

`osi` is a friendly wrapper over `osiris`. First tool: a **YAML-driven job
launcher**. You describe a job in a config file; `osi` resolves defaults and
dynamic values, composes the awkward `osiris` args, and calls
`osiris.create()`.

Decisions locked in:
- **Eval engine:** hybrid — OmegaConf resolvers (safe/declarative) + a
  restricted Python escape hatch.
- **CLI:** Click.
- **Scope (v1):** launch + dry-run (`show`/`--dry-run`) + bash render (`bash`).
  Monitoring etc. are later osi tools.

See `osiris-launch-api.md` for the underlying API this maps onto.

---

## 1. Core UX win: structured config instead of a flat `args` list

The biggest osiris pain is the single order-sensitive `args` list. `osi` splits
it into named pieces and composes the flat list for you:

```yaml
# train.yaml
name: "train-${py:uuid4_short(5)}"   # -> train-9ab3c
image: registry/img:latest
pool: my-pool
nodes: [node-0, node-1]
# num_nodes omitted -> defaults to len(nodes)
# num_gpus / type / restart / script -> defaults

envs:
  PYTHONPATH: /path/to/venv

run:
  command: torchrun                  # entrypoint
  launcher_args:                     # torchrun opts (same flattening as script_args)
    nproc_per_node: 8                # -> --nproc_per_node 8  (separate tokens)
  script: train.py                   # script_path (NOT osiris.script)
  script_args:                       # conventional flags
    path: /data/folder               # -> --path /data/folder
    resume: true                     # -> --resume   (false -> omitted)
  overrides:                         # hydra overrides, one element each
    - data.batch_size=2
    - trainer.max_steps=1000
```

`osi` composes `osiris` `args` in the required order
(`[*launcher_args, script, *flatten(script_args), *overrides]`):

```python
args = [
    "--nproc_per_node", "8",   # launcher_args (flag -> two separate tokens)
    "train.py",                # script
    "--path", "/data/folder",  # script_args (flag -> two tokens)
    "--resume",                # bool true -> single token
    "data.batch_size=2",       # overrides (one token each, never split)
    "trainer.max_steps=1000",
]
```

### `launcher_args` / `script_args` flattening rules
Both use the **same** rules, and a flag plus its value become **two separate
strings** (`["--key", "value"]`) — never a single `--key=value` token:
- `key: value` → `["--key", "str(value)"]`
- `key: true` → `["--key"]`; `key: false` → omitted (store_true semantics)
- `key: [a, b]` → `["--key", "a", "--key", "b"]` (repeated flag)
- Underscores kept by default (`max_steps` → `--max_steps`); optional
  `dash_keys: true` setting converts `_`→`-`.
- Escape hatch: either may instead be given as a raw `list[str]` for full
  control (passed through verbatim).

### Command-aware `launcher_args` defaults
The default `launcher_args` depend on the launcher, matched on
**`basename(command)`** (i.e. `command.split("/")[-1]`) since `command` may be a
full path like `/opt/root/.../torchrun`.

When the basename is `torchrun`, osi injects these defaults:

```yaml
launcher_args:                 # torchrun defaults
  nnodes: ${num_nodes}                                  # -> --nnodes <len(nodes)>
  nproc_per_node: ${num_gpus}                           # -> --nproc_per_node 8
  node_rank: "$(RANK)"                                  # literal, filled at runtime
  master_addr: "$(MASTER_ADDR).datalab.svc.cluster.local"
  master-port: "$(MASTER_PORT)"                         # note: dash, kept verbatim
```

Which flatten (separate-token rule) to:

```python
["--nnodes", "2", "--nproc_per_node", "8",
 "--node_rank", "$(RANK)",
 "--master_addr", "$(MASTER_ADDR).datalab.svc.cluster.local",
 "--master-port", "$(MASTER_PORT)"]
```

Notes:
- `nnodes` is tied to `num_nodes` (= `len(nodes)`) and `nproc_per_node` to
  `num_gpus`, so they stay consistent with the rest of the config instead of
  being hard-coded.
- `$(RANK)`, `$(MASTER_ADDR)`, `$(MASTER_PORT)` use **`$(...)`** (parentheses),
  which OmegaConf does **not** interpolate (it only touches `${...}`), so they
  pass through literally for the platform to fill in.
- Key spellings are preserved verbatim, so the intentional `master-port` dash vs
  the underscores elsewhere is kept exactly.
- **Merge semantics:** user-supplied `launcher_args` keys override the matching
  default keys (e.g. set just `nproc_per_node: 4`); set a key to `null` to drop a
  default; or pass a raw `list[str]` to replace the defaults entirely.
- The launcher→defaults mapping is a small registry (`torchrun` first), easy to
  extend later.

### `overrides`
Always emitted as one list element each — never split on `=`. This is exactly
the hydra-override case from the osiris spec.

---

## 2. Defaults (layered)

Resolution order, later wins:

1. **Built-in defaults** (shipped in `osi`)
2. **User defaults file** — optional `~/.config/osi/defaults.yaml` or a path via
   `--defaults`
3. **Job YAML** (the file passed to `osi launch`)
4. **CLI overrides** — `--set key=value` (repeatable) and shortcut flags

Built-in defaults:

| Field | Default |
|-------|---------|
| `script` | `""` (always; real path lives in `run.script`) |
| `restart` | `False` |
| `num_gpus` | `8` |
| `type` | `"pytorchjob"` |
| `timezone` | `"UTC"` (override per project; also reads `OSI_TZ` env) — used by `${date:}` |
| `num_nodes` | `${len:nodes}` (lazy, derived from `nodes`) |
| `run.command` | `"python"` |
| `run.launcher_args` | command-aware: `torchrun` → torchrun default set (see §1); else `[]` |
| `run.script_args` | `{}` |
| `run.overrides` | `[]` |

So a minimal config only needs `name`, `image`, `pool`, `nodes`, `envs`, and
`run.script`.

---

## 3. Eval engine (hybrid)

Loading goes through **OmegaConf**, which the codebase already touches via Hydra.
Two layers:

### a) OmegaConf resolvers (recommended, safe)
Registered custom resolvers for the common dynamic cases:

| Resolver | Example | Result |
|----------|---------|--------|
| `uuid4` | `${uuid4:}` | full uuid |
| `uuid4_short` | `${uuid4_short:5}` | first 5 chars |
| `len` | `${len:nodes}` | `len(nodes)` |
| `env` | `${env:HOME}` | env var (OmegaConf builtin: `${oc.env:...}`) |
| `date` | `${date:}` | date string in the predefined timezone — see below |
| `stem` | `${stem:ckpt_path}` | filename without dir/ext (`epoch_1`) |
| `basename` | `${basename:ckpt_path}` | filename with ext (`epoch_1.ckpt`) |
| `regex` | `${regex:PATTERN,SRC}` | first capture group of `PATTERN` in `SRC` |
| `split` | `${split:SRC,SEP,IDX}` | `SRC.split(SEP)[IDX]` |
| `replace` | `${replace:SRC,OLD,NEW}` | string replace |

These are declarative, reproducible, and don't execute arbitrary code. They also
resolve **lazily**, so `num_nodes: ${len:nodes}` correctly sees the final
`nodes` value even if `nodes` itself was overridden on the CLI.

#### `date` resolver (timezone-aware)
Replaces the hand-written
`datetime.now(ZoneInfo(timezone)).strftime("%d-%m-%Y")` pattern used to stamp
experiment names.

Signature: `${date:[FORMAT][,TZ]}`
- `FORMAT` — strftime format; default `%d-%m-%Y` (your usual `19-06-2026`).
- `TZ` — IANA zone (e.g. `Europe/Berlin`); defaults to the **predefined**
  top-level `timezone` config key, so you set it once and never repeat it.

```yaml
timezone: Europe/Berlin                 # predefined once (default for all dates)

exp_date: ${date:}                      # -> 19-06-2026  (default fmt + tz)
name: "${exp_date}-exp-name-${py:uuid4_short(4)}"   # 19-06-2026-exp-name-9ab3
run:
  overrides:
    - logger.run_name=${exp_date}       # same string reused for the hydra/exp logger
    - "logger.tags=[${exp_date}]"
```

Examples: `${date:%Y%m%d}` → `20260619`; `${date:%Y-%m-%d,Asia/Tokyo}` →
date in Tokyo regardless of the predefined zone.

> **Reuse it once:** define `exp_date: ${date:}` and reference `${exp_date}`
> everywhere (name *and* overrides). OmegaConf resolves the key once and caches
> it, so the name and the value you pass into the hydra/logger cfg are guaranteed
> identical — no risk of two `${date:}` calls landing on opposite sides of
> midnight.

Implementation: `datetime.now(ZoneInfo(tz or cfg.timezone)).strftime(fmt)`.

#### String parsing (derive values from other strings)
Common need: pull a piece out of another value — e.g. the epoch number from a
checkpoint path — and feed it into the name / hydra run_name.

Two layers, same hybrid philosophy:

- **Declarative resolvers** for simple, readable path/string ops (`stem`,
  `basename`, `split`, `replace`, `regex`). Good for the 90% case:

  ```yaml
  ckpt_path: ".../epoch_1.ckpt"
  epoch: ${split:${stem:ckpt_path},_,1}       # stem -> epoch_1 ; split on _ -> "1"
  run:
    overrides:
      - logger.run_name=epoch-${epoch}
  ```

- **`${py:...}` escape hatch** for arbitrary patterns, with `re`/`Path` helpers
  in scope (see whitelist below):

  ```yaml
  epoch: ${py:re_search(r'epoch_(\d+)', ckpt_path)}   # any pattern you like
  ```

Caveats:
- OmegaConf resolver args split on **commas** and backslashes need YAML quoting,
  so `${regex:...}` gets awkward for non-trivial patterns. **Lean on `${py:}` for
  real regex**, declarative resolvers for simple path slicing.
- **Parse once, reuse:** define `epoch: ...` once and reference `${epoch}`
  everywhere (name *and* overrides), like the `date` pattern above.

### b) `${py:...}` restricted Python escape hatch
For anything the resolvers don't cover, evaluate a Python expression in a
sandboxed namespace:

```yaml
name: "train-${py:uuid4_short(5)}"
num_nodes: ${py:len(nodes)}
tag:  "${py:'big' if len(nodes) > 4 else 'small'}"
```

- Evaluated with `eval(expr, {"__builtins__": {}}, ns)`.
- `ns` exposes a **whitelist**: `uuid4`, `uuid4_short`, `len`, `str`, `int`,
  `range`, `datetime`; parsing helpers `re_search`, `re_sub`, `stem`,
  `basename`, `Path`; plus the already-resolved sibling config values (so
  `nodes`, `ckpt_path`, `pool`, etc. are referenceable).
- `re_search(pattern, s)` returns capture group 1 (or the whole match if no
  group), so the common case is a one-liner without `.group(1)` chains.
- No imports, no builtins, no attribute access to dunders — opt-in and bounded.

> Your original `name="train-{uuid4()}"` ergonomics: `osi` will also accept the
> bare-brace form `"{uuid4_short(5)}"` and rewrite it to `${py:...}` before
> parsing, so you can keep writing it the way you do. The `${py:...}` form is
> the canonical one in docs.

**Why hybrid:** resolvers cover 90% cleanly and safely; `${py:...}` is the
pressure-release valve so you're never blocked, with the unsafe surface area
isolated to one clearly-marked feature.

---

## 4. Config → `osiris.create()` mapping

| osi config | osiris.create arg |
|------------|-------------------|
| `name` | `name` |
| `image` | `image` |
| `script` (default `""`) | `script` |
| `run.command` | `command` |
| `restart` | `restart` |
| `pool` | `pool` |
| `nodes` | `nodes` |
| `num_nodes` (default `len(nodes)`) | `num_nodes` |
| `num_gpus` | `num_gpus` |
| `type` | `type` |
| `envs` | `envs` |
| composed `run.*` | `args` |

---

## 5. Validation

After `OmegaConf.to_container(resolve=True)`, validate with a **pydantic v2**
model for friendly, precise errors before anything hits osiris:

- Required: `name`, `image`, `pool`, `nodes` (non-empty), `run.script`.
- Type checks on every field; `envs` values coerced to `str`.
- `num_gpus > 0`, `num_nodes == len(nodes)` warning if mismatch.
- Clear message pointing at the offending YAML key on failure.

---

## 6. CLI (Click)

```
osi launch CONFIG.yaml [options]      # resolve + validate + submit
osi show   CONFIG.yaml [options]       # dry-run: resolve + validate, print, no submit
osi bash   CONFIG.yaml [options]       # print equivalent bash script string to stdout

Shared options:
  --set KEY=VALUE      Override any config key (repeatable, dotted keys)
  --name TEXT          Shortcut override for name
  --pool TEXT          Shortcut override for pool
  --defaults PATH      Extra defaults file (layer 2)

launch-only:
  --dry-run            Same as `osi show` — resolve everything and print the exact
                       osiris.create() kwargs, then exit WITHOUT submitting
  -v, --verbose        Print resolved config + composed args before submitting
  -q, --quiet          Suppress printing the returned osiris dict on success
                       (default: print it to stdout as JSON)
```

`osi launch train.yaml --set run.overrides[0]=data.batch_size=4` style overrides
ride on OmegaConf dotlist merging.

Programmatic API (the "code tool" half) mirrors the CLI:

```python
from osi import launch, resolve, to_bash

cfg  = resolve("train.yaml", overrides={"pool": "other-pool"})  # dry-run dict
sh   = to_bash("train.yaml")                                    # bash script str
info = launch("train.yaml")                                     # submit; returns osiris dict
```

`launch()` returns the **exact dict from `osiris.create()`** unchanged (job info)
— `osi` does not reshape or swallow it. The `osi launch` CLI prints that same dict
to stdout as JSON on success (so it's pipeable/capturable); add `-q/--quiet` to
suppress. Non-zero exit on validation or osiris errors.

All paths funnel through the same `load → resolve → validate → compose` pipeline;
only the final step differs (`create` / print / render).

---

## 6b. Dry-run & bash render

### Dry-run (`osi show` / `osi launch --dry-run`, `resolve()`)
Runs the full pipeline up to (but not including) `osiris.create()` and prints,
with zero side effects:
1. the **resolved config** (defaults merged, every `${...}`/`${py:...}` evaluated,
   `num_nodes` filled, dates stamped), as YAML; and
2. the exact **`osiris.create()` kwargs** that *would* be submitted, including the
   final composed flat `args` list.

`resolve(config, overrides=...) -> dict` returns that same resolved structure for
programmatic inspection/testing. This is the cheap correctness check before
burning a cluster slot.

### Bash render (`osi bash`, `to_bash()`)
Converts the resolved config into the equivalent shell invocation and returns it
as a **string** (printed to stdout by the CLI; returned by `to_bash()`). No file
is written — output only.

Shape:
```bash
#!/usr/bin/env bash
export PYTHONPATH='/path/to/venv'
torchrun \
  --nnodes 2 \
  --nproc_per_node 8 \
  --node_rank "${RANK}" \
  --master_addr "${MASTER_ADDR}.datalab.svc.cluster.local" \
  --master-port "${MASTER_PORT}" \
  train.py \
  --path '/data/folder' \
  --resume \
  data.batch_size=2 \
  trainer.max_steps=1000
```

Rules:
- `envs` → one `export K=V` per entry, values shell-quoted.
- Body = `run.command` + the same composed `args` list used for osiris, so the
  bash output and the real job stay in lockstep (both built by `args_builder`).
- Tokens are shell-quoted; each flag/arg on its own `\`-continued line for
  readability. (A `--oneline` option can emit a single-line command.)
- **Placeholder translation:** k8s-style `$(VAR)` (which is command substitution
  in bash) is rewritten to `"${VAR}"` so the script references env vars instead of
  executing them. Toggle with `--literal-placeholders` to keep `$(VAR)` verbatim.

## 7. Package layout

```
osi/
  pyproject.toml          # entry point: osi = osi.cli:main ; deps: click, omegaconf, pydantic
  src/osi/
    __init__.py           # exposes launch(), resolve(), to_bash()
    cli.py                # Click commands (launch, show, bash)
    config.py             # load + layer + resolve (OmegaConf)
    resolvers.py          # uuid4, uuid4_short, len, env, date(tz),
                          #   stem/basename/regex/split/replace, py (+ registration)
    schema.py             # pydantic model + validation
    args_builder.py       # compose flat osiris args list
    render.py             # to_bash(): resolved cfg -> bash script string
    launcher.py           # map config -> osiris.create kwargs -> call osiris
  configs/
    defaults.yaml         # built-in defaults
    examples/train.yaml   # the example above
  docs/
    usage.md              # short user guide — see §10
  tests/
    test_args_builder.py  # ordering, flag/bool/list, overrides-not-split,
                          #   command-aware torchrun defaults + merge/override
    test_resolvers.py     # uuid/len/date(tz)/stem/split/regex/py-parse + namespace safety
    test_config.py        # layering precedence, lazy num_nodes
    test_schema.py        # validation errors
    test_render.py        # to_bash: env exports, quoting, $(VAR)->${VAR}, oneline
```

---

## 8. Pipeline (one path for CLI and code)

```
load YAML ─► layer defaults ─► register+resolve (OmegaConf, lazy)
   ─► to_container(resolve=True) ─► validate (pydantic)
   ─► compose run.* into flat args ─► build osiris.create kwargs
   ─► [ launch ]  osiris.create(**kwargs) ─► return that dict (CLI prints it as JSON)
   ─► [ show   ]  print resolved cfg + kwargs, exit (no submit)
   ─► [ bash   ]  render bash script string, print/return (no submit)
```
Only the terminal step differs between the three commands.

---

## 9. Implementation order

1. `resolvers.py` — resolvers + `${py:...}`, with safety tests.
2. `args_builder.py` — the composition logic + tests (pure, no osiris needed).
3. `config.py` — loading/layering/resolution.
4. `schema.py` — pydantic validation.
5. `render.py` — `to_bash()` (pure, testable without osiris).
6. `launcher.py` — mapping + `osiris.create()` call.
7. `cli.py` — Click `osi launch` / `show` / `bash`, `--set`, `--dry-run`, `-v`.
8. `configs/` + example, end-to-end smoke test.
9. `docs/usage.md` — write alongside the features (see §10); keep it current as
   the tool grows.

---

## 10. User documentation (`docs/usage.md`)

Functionality is growing, so the tool ships a **short** user guide — descriptions
plus a copy-pasteable example for each feature, not exhaustive prose. Target a
single skimmable page that lets someone write a config without reading the code.

Cover, each with a 1–2 line description and a minimal YAML example:
- Quickstart: minimal config + `osi launch` (what's required vs defaulted).
- The config schema: top-level fields and the `run.*` block.
- `run` composition: `launcher_args` / `script_args` / `overrides` and the
  flattening rules (separate-token flags, bools, lists, raw-list escape hatch).
- Command-aware launcher defaults (torchrun) and how to override/drop them.
- Eval engine: the resolver table (`uuid4`, `len`, `date`, `stem`, `regex`, …)
  and the `${py:...}` escape hatch + its whitelist.
- Recipes for the real workflows: dynamic name, date-stamped run_name, parsing
  the epoch out of a ckpt path — including the "parse/define once, reuse
  `${...}`" pattern.
- Commands: `launch`, `show` / `--dry-run`, `bash`, and `--set` overrides.
- Python API: `launch()`, `resolve()`, `to_bash()`.

Keep examples runnable and in sync with `configs/examples/`. Each new
feature lands with its docs entry in the same change.

---

## 11. Deferred (not v1, but architecture-ready)
- `osi status` / `osi logs` / `osi kill` — the monitoring tools.
- Config includes/inheritance (`extends: base.yaml`).
- Multi-job sweeps from one file.
