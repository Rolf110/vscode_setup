import os

import pytest

from osi.config import resolve_config
from osi.resolvers import PyEvalError, eval_py


def r(cfg, **kw):
    return resolve_config(cfg, **kw)


def test_uuid4_short_len():
    cfg = r({"name": "${uuid4_short:5}", "nodes": ["a"], "run": {"script": "t.py"}})
    assert len(cfg["name"]) == 5


def test_len_resolver_reads_key():
    cfg = r({"nodes": ["a", "b", "c"], "k": "${len:nodes}", "run": {"script": "t.py"}})
    assert cfg["k"] == 3


def test_num_nodes_defaults_to_len_nodes_lazily():
    cfg = r({"name": "n", "image": "i", "pool": "p",
             "nodes": ["a", "b"], "run": {"script": "t.py"}})
    assert cfg["num_nodes"] == 2


def test_date_default_format_and_tz_override():
    cfg = r({"timezone": "Europe/Berlin",
             "d": "${date:%Y}", "nodes": ["a"], "run": {"script": "t.py"}})
    assert cfg["d"].isdigit() and len(cfg["d"]) == 4


def test_date_uses_predefined_timezone_key():
    cfg = r({"timezone": "UTC", "d": "${date:%z}", "nodes": ["a"],
             "run": {"script": "t.py"}})
    assert cfg["d"] in ("+0000", "")  # UTC offset


def test_stem_and_split_string_parsing():
    cfg = r({"ckpt_path": "/x/y/epoch_1.ckpt",
             "epoch": "${split:${stem:ckpt_path},_,1}",
             "nodes": ["a"], "run": {"script": "t.py"}})
    assert cfg["epoch"] == "1"


def test_basename_and_regex():
    # regex patterns with special chars (parens, \d) must be quoted so OmegaConf
    # passes them through verbatim; for anything complex, prefer ${py:}.
    cfg = r({"ckpt_path": "/x/epoch_42.ckpt",
             "b": "${basename:ckpt_path}",
             "e": "${regex:'epoch_(\\d+)',ckpt_path}",
             "nodes": ["a"], "run": {"script": "t.py"}})
    assert cfg["b"] == "epoch_42.ckpt"
    assert cfg["e"] == "42"


def test_py_parses_epoch_from_ckpt():
    cfg = r({"ckpt_path": "/x/epoch_7.ckpt",
             "epoch": "${py:re_search(r'epoch_(\\d+)', ckpt_path)}",
             "nodes": ["a"], "run": {"script": "t.py"}})
    assert cfg["epoch"] == "7"


def test_py_reuse_via_interpolation_is_consistent():
    cfg = r({
        "exp_date": "${date:%Y%m%d}",
        "name": "${exp_date}-x",
        "nodes": ["a"],
        "run": {"script": "t.py", "overrides": ["run_name=${exp_date}"]},
    })
    stamp = cfg["exp_date"]
    assert cfg["name"] == f"{stamp}-x"
    assert cfg["run"]["overrides"] == [f"run_name={stamp}"]


def test_brace_form_rewritten_to_py():
    cfg = r({"name": "train-{uuid4_short(4)}", "nodes": ["a"],
             "run": {"script": "t.py"}})
    assert cfg["name"].startswith("train-") and len(cfg["name"]) == len("train-") + 4


def test_py_dunder_blocked():
    with pytest.raises(PyEvalError):
        eval_py("().__class__", {})


def test_py_no_builtins():
    with pytest.raises(PyEvalError):
        eval_py("open('x')", {})
