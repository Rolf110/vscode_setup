"""OmegaConf custom resolvers + the restricted ``${py:...}`` escape hatch.

Two layers (the hybrid eval engine from the plan):

* Declarative OmegaConf resolvers (``uuid4``, ``uuid4_short``, ``len``, ``env``,
  ``date``, ``stem``, ``basename``, ``regex``, ``split``, ``replace``) — safe,
  reproducible, no arbitrary code.
* ``${py:EXPR}`` — a restricted Python expression evaluated in a sandboxed
  namespace.  OmegaConf's interpolation grammar cannot parse Python (parens,
  dots, spaces all break it), so ``py`` is handled by a separate sentinel pass
  in :mod:`osi.config`, not as an OmegaConf resolver.  This module only provides
  the namespace + evaluator it uses.
"""

from __future__ import annotations

import os
import re
import uuid
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from omegaconf import DictConfig, OmegaConf

DEFAULT_DATE_FMT = "%d-%m-%Y"
DEFAULT_TZ = "UTC"


# --------------------------------------------------------------------------- #
# small helpers shared by resolvers and the py namespace
# --------------------------------------------------------------------------- #
def uuid4() -> str:
    return str(uuid.uuid4())


def uuid4_short(n: int = 5) -> str:
    return str(uuid.uuid4())[: int(n)]


def stem(path: str) -> str:
    """Filename without directory or final extension: ``a/epoch_1.ckpt`` -> ``epoch_1``."""
    return Path(str(path)).stem


def basename(path: str) -> str:
    """Filename with extension: ``a/epoch_1.ckpt`` -> ``epoch_1.ckpt``."""
    return Path(str(path)).name


def re_search(pattern: str, s: str):
    """First capture group of ``pattern`` in ``s`` (or the whole match if the
    pattern has no groups). Returns ``None`` if there is no match."""
    m = re.search(pattern, str(s))
    if not m:
        return None
    return m.group(1) if m.groups() else m.group(0)


def re_sub(pattern: str, repl: str, s: str) -> str:
    return re.sub(pattern, repl, str(s))


def _now(fmt: str, tz: str) -> str:
    return datetime.now(ZoneInfo(tz)).strftime(fmt)


# --------------------------------------------------------------------------- #
# OmegaConf resolvers
# --------------------------------------------------------------------------- #
def _deref(x, root):
    """Resolve a resolver argument that may be a *key path* in the config.

    ``${len:nodes}`` / ``${stem:ckpt_path}`` pass the literal string
    ``"nodes"`` / ``"ckpt_path"``.  If that string is an existing key in the
    config we use the key's value; otherwise we treat it as a literal (e.g. the
    nested ``${split:${stem:ckpt_path},_,1}`` where the first arg is already the
    resolved stem value).
    """
    if isinstance(x, str) and root is not None:
        try:
            sel = OmegaConf.select(root, x, throw_on_missing=False)
        except Exception:
            sel = None
        if sel is not None:
            return sel
    return x


def _r_uuid4(_root_=None):
    return uuid4()


def _r_uuid4_short(n: int = 5, _root_=None):
    return uuid4_short(n)


def _r_len(x, _root_=None):
    return len(_deref(x, _root_))


def _r_env(name: str, default: str = "", _root_=None):
    return os.environ.get(str(name), default)


def _default_tz(root) -> str:
    if root is not None:
        try:
            tz = OmegaConf.select(root, "timezone", throw_on_missing=False)
        except Exception:
            tz = None
        if tz:
            return str(tz)
    return os.environ.get("OSI_TZ") or DEFAULT_TZ


def _r_date(fmt: str = "", tz: str = "", _root_=None):
    fmt = str(fmt) if fmt else DEFAULT_DATE_FMT
    tz = str(tz) if tz else _default_tz(_root_)
    return _now(fmt, tz)


def _r_stem(x, _root_=None):
    return stem(_deref(x, _root_))


def _r_basename(x, _root_=None):
    return basename(_deref(x, _root_))


def _r_regex(pattern: str, src: str, _root_=None):
    out = re_search(pattern, _deref(src, _root_))
    return "" if out is None else out


def _r_split(src: str, sep: str, idx, _root_=None):
    return str(_deref(src, _root_)).split(str(sep))[int(idx)]


def _r_replace(src: str, old: str, new: str, _root_=None):
    return str(_deref(src, _root_)).replace(str(old), str(new))


_RESOLVERS = {
    "uuid4": _r_uuid4,
    "uuid4_short": _r_uuid4_short,
    "len": _r_len,
    "env": _r_env,
    "date": _r_date,
    "stem": _r_stem,
    "basename": _r_basename,
    "regex": _r_regex,
    "split": _r_split,
    "replace": _r_replace,
}


def register_resolvers(replace: bool = True) -> None:
    """Register all osi resolvers with OmegaConf. Idempotent."""
    for name, fn in _RESOLVERS.items():
        OmegaConf.register_new_resolver(name, fn, use_cache=False, replace=replace)


# --------------------------------------------------------------------------- #
# ${py:...} restricted evaluation
# --------------------------------------------------------------------------- #
# Whitelisted callables/values available inside ${py:...}. No __builtins__.
PY_NAMESPACE_FUNCS = {
    "uuid4": uuid4,
    "uuid4_short": uuid4_short,
    "len": len,
    "str": str,
    "int": int,
    "float": float,
    "range": range,
    "datetime": datetime,
    "re_search": re_search,
    "re_sub": re_sub,
    "stem": stem,
    "basename": basename,
    "Path": Path,
}


class PyEvalError(RuntimeError):
    pass


def eval_py(expr: str, context: dict):
    """Evaluate a ``${py:...}`` expression in the sandboxed namespace.

    ``context`` provides the already-resolved sibling config values (so the
    expression can reference ``nodes``, ``ckpt_path``, ...). Dunder access is
    blocked and there are no builtins.
    """
    if "__" in expr:
        raise PyEvalError(f"dunder access is not allowed in ${{py:}}: {expr!r}")
    ns = dict(PY_NAMESPACE_FUNCS)
    ns.update(context)
    try:
        return eval(expr, {"__builtins__": {}}, ns)  # noqa: S307 - sandboxed
    except PyEvalError:
        raise
    except Exception as ex:  # pragma: no cover - message passthrough
        raise PyEvalError(f"error evaluating ${{py:{expr}}}: {ex}") from ex
