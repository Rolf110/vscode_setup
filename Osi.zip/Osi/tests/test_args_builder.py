from osi import args_builder as ab


def test_dict_flag_value_separate_tokens():
    assert ab.flag_groups({"path": "/data"}) == [["--path", "/data"]]


def test_bool_true_is_store_true_false_omitted():
    groups = ab.flag_groups({"resume": True, "amp": False})
    assert groups == [["--resume"]]


def test_list_repeats_flag():
    assert ab.flag_groups({"tag": ["a", "b"]}) == [["--tag", "a"], ["--tag", "b"]]


def test_none_value_dropped():
    assert ab.flag_groups({"x": None}) == []


def test_dash_keys_conversion():
    assert ab.flag_groups({"max_steps": 5}, dash_keys=True) == [["--max-steps", "5"]]
    assert ab.flag_groups({"max_steps": 5}) == [["--max_steps", "5"]]


def test_raw_list_passthrough_verbatim():
    assert ab.flag_groups(["--foo=bar", "x"]) == [["--foo=bar"], ["x"]]


def test_torchrun_matched_on_basename_of_full_path():
    run = {"command": "/opt/root/bin/torchrun", "script": "t.py", "launcher_args": {}}
    args = ab.compose_args(run, num_nodes=4, num_gpus=8)
    assert args[:2] == ["--nnodes", "4"]
    assert args[2:4] == ["--nproc_per_node", "8"]


def test_torchrun_full_default_order():
    run = {"command": "torchrun", "script": "t.py", "launcher_args": {}}
    args = ab.compose_args(run, num_nodes=2, num_gpus=8)
    assert args == [
        "--nnodes", "2",
        "--nproc_per_node", "8",
        "--node_rank", "$(RANK)",
        "--master_addr", "$(MASTER_ADDR).datalab.svc.cluster.local",
        "--master-port", "$(MASTER_PORT)",
        "t.py",
    ]


def test_user_overrides_torchrun_default_and_drops_with_null():
    run = {
        "command": "torchrun",
        "script": "t.py",
        "launcher_args": {"nproc_per_node": 4, "master-port": None},
    }
    args = ab.compose_args(run, num_nodes=2, num_gpus=8)
    assert "--nproc_per_node" in args
    assert args[args.index("--nproc_per_node") + 1] == "4"
    assert "--master-port" not in args


def test_raw_list_replaces_torchrun_defaults():
    run = {"command": "torchrun", "script": "t.py", "launcher_args": ["--standalone"]}
    args = ab.compose_args(run, num_nodes=2, num_gpus=8)
    assert args == ["--standalone", "t.py"]


def test_python_command_has_no_launcher_defaults():
    run = {"command": "python", "script": "t.py"}
    assert ab.compose_args(run, num_nodes=2, num_gpus=8) == ["t.py"]


def test_full_composition_order_matches_plan():
    run = {
        "command": "torchrun",
        "launcher_args": {"nproc_per_node": 8},
        "script": "train.py",
        "script_args": {"path": "/data/folder", "resume": True},
        "overrides": ["data.batch_size=2", "trainer.max_steps=1000"],
    }
    args = ab.compose_args(run, num_nodes=2, num_gpus=8)
    # script path precedes script_args; overrides last and never split on '='
    assert args.index("train.py") < args.index("--path")
    assert args[-2:] == ["data.batch_size=2", "trainer.max_steps=1000"]
    assert "--resume" in args


def test_overrides_never_split():
    run = {"command": "python", "script": "t.py", "overrides": ["a.b=c=d"]}
    args = ab.compose_args(run, num_nodes=1, num_gpus=8)
    assert args[-1] == "a.b=c=d"
