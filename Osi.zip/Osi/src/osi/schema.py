"""Pydantic v2 validation of a resolved osi config.

Validation runs *after* all interpolation/eval, so every field is concrete.
Extra top-level keys are allowed (people define intermediate keys like
``ckpt_path`` / ``exp_date`` purely to interpolate from).
"""

from __future__ import annotations

import warnings
from typing import Any, Dict, List, Union

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class RunModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    command: str = "python"
    script: str = Field(..., min_length=1)
    launcher_args: Union[Dict[str, Any], List[str]] = Field(default_factory=dict)
    script_args: Union[Dict[str, Any], List[str]] = Field(default_factory=dict)
    overrides: List[str] = Field(default_factory=list)
    dash_keys: bool = False

    @field_validator("overrides", mode="before")
    @classmethod
    def _coerce_overrides(cls, v):
        if v is None:
            return []
        return [str(x) for x in v]


class JobModel(BaseModel):
    model_config = ConfigDict(extra="allow")

    name: str = Field(..., min_length=1)
    image: str = Field(..., min_length=1)
    pool: str = Field(..., min_length=1)
    nodes: List[str] = Field(..., min_length=1)
    num_nodes: int = Field(..., gt=0)
    num_gpus: int = Field(8, gt=0)
    type: str = "pytorchjob"
    restart: bool = False
    script: str = ""
    timezone: str = "UTC"
    envs: Dict[str, str] = Field(default_factory=dict)
    run: RunModel

    @field_validator("nodes", mode="before")
    @classmethod
    def _coerce_nodes(cls, v):
        if v is None:
            return v
        return [str(x) for x in v]

    @field_validator("envs", mode="before")
    @classmethod
    def _coerce_envs(cls, v):
        if not v:
            return {}
        return {str(k): str(val) for k, val in dict(v).items()}

    @model_validator(mode="after")
    def _check_num_nodes(self):
        if self.num_nodes != len(self.nodes):
            warnings.warn(
                f"num_nodes ({self.num_nodes}) != len(nodes) ({len(self.nodes)})",
                stacklevel=2,
            )
        return self


def validate(cfg: dict) -> dict:
    """Validate a resolved config dict; return the normalized dict.

    Raises ``pydantic.ValidationError`` with a clear, keyed message on failure.
    """
    model = JobModel.model_validate(cfg)
    return model.model_dump()
