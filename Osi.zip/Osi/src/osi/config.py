"""Load, layer, and resolve osi configs.

Resolution is a hybrid pass (see the design plan):

1. Merge the layers (builtin defaults < user defaults < job yaml < ``--set``).
2. Rewrite the bare-brace form ``{expr}`` to ``${py:expr}`` and pull every
   ``${py:EXPR}`` out into a sentinel token (OmegaConf's grammar can't parse
   Python, so ``py`` is handled here, not as a resolver).
3. Let OmegaConf resolve all standard interpolations (``${len:nodes}``,
   ``${date:}``, ``${key}`` refs, ...).  References to a ``py`` key carry the
   sentinel along.
4. Evaluate the ``py`` sentinels in dependency order against the resolved
   siblings, splicing results back in (handles "define once, reuse ``${...}``").
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Iterable, Mapping

import yaml
from omegaconf import DictConfig, OmegaConf

from . import resolvers

_DEFAULTS_FILE = Path(__file__).parent / "configs" / "defaults.yaml"
_USER_DEFAULTS = Path.home() / ".config" / "osi" / "defaults.yaml"

# bare ``{expr}`` not preceded by ``$`` (so ``${len:..}`` is left alone)
_BRACE_RE = re.compile(r"(?<!\$)\{([^{}]+)\}")
_PY_OPEN = "${py:"
_SENTINEL = "\x00OSIPY{}\x00"
_MAX_PASSES = 25


# --------------------------------------------------------------------------- #
# loading + layering (plain dicts; OmegaConf rejects ${py:...} at load time, so
# we merge + protect before it ever sees the config)
# --------------------------------------------------------------------------- #
def _raw_layer(src: Any) -> dict:
    if isinstance(src, (str, Path)):
        with open(src) as fh:
            return yaml.safe_load(fh) or {}
    if isinstance(src, DictConfig):
        return OmegaConf.to_container(src, resolve=False)  # type: ignore[return-value]
    if isinstance(src, Mapping):
        return dict(src)
    raise TypeError(f"unsupported config source: {type(src).__name__}")


def _deep_merge(a: dict, b: dict) -> dict:
    out = dict(a)
    for k, v in b.items():
        if isinstance(out.get(k), dict) and isinstance(v, dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def _coerce_scalar(s: str) -> Any:
    low = s.lower()
    if low in ("true", "false"):
        return low == "true"
    if low in ("null", "none", "~"):
        return None
    for cast in (int, float):
        try:
            return cast(s)
        except ValueError:
            pass
    return s


def _dotlist_to_dict(set_list: Iterable[str]) -> dict:
    """Parse ``a.b.c=value`` entries into a nested dict (value coerced)."""
    out: dict = {}
    for item in set_list:
        if "=" not in item:
            raise ValueError(f"--set expects KEY=VALUE, got {item!r}")
        key, _, value = item.partition("=")
        node = out
        parts = key.strip().split(".")
        for p in parts[:-1]:
            node = node.setdefault(p, {})
        node[parts[-1]] = _coerce_scalar(value)
    return out


def load_merged_raw(
    config: Any,
    *,
    overrides: Mapping[str, Any] | None = None,
    set_list: Iterable[str] | None = None,
    defaults_path: str | Path | None = None,
) -> dict:
    """Merge all layers into one (unresolved) plain dict."""
    raw: dict = _raw_layer(_DEFAULTS_FILE)
    if defaults_path:
        raw = _deep_merge(raw, _raw_layer(defaults_path))
    elif _USER_DEFAULTS.exists():
        raw = _deep_merge(raw, _raw_layer(_USER_DEFAULTS))
    raw = _deep_merge(raw, _raw_layer(config))
    if overrides:
        raw = _deep_merge(raw, dict(overrides))
    if set_list:
        raw = _deep_merge(raw, _dotlist_to_dict(set_list))
    return raw


# --------------------------------------------------------------------------- #
# ${py:...} extraction
# --------------------------------------------------------------------------- #
def _extract_py(s: str, sink) -> str:
    """Replace each ``${py:EXPR}`` in ``s`` with a sentinel via ``sink(expr)``.

    Brace-matched so the EXPR may itself contain ``(`` ``)`` ``,`` etc.
    """
    out: list[str] = []
    i = 0
    while True:
        j = s.find(_PY_OPEN, i)
        if j == -1:
            out.append(s[i:])
            return "".join(out)
        out.append(s[i:j])
        k = j + len(_PY_OPEN)
        depth = 1
        while k < len(s):
            c = s[k]
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    break
            k += 1
        expr = s[j + len(_PY_OPEN) : k]
        out.append(sink(expr))
        i = k + 1


def _protect_pys(container: Any, exprs: list[str]) -> Any:
    """Walk container; rewrite braces -> ${py:} and ${py:} -> sentinels."""

    def sink(expr: str) -> str:
        exprs.append(expr.strip())
        return _SENTINEL.format(len(exprs) - 1)

    def walk(node: Any) -> Any:
        if isinstance(node, str):
            return _extract_py(_BRACE_RE.sub(r"${py:\1}", node), sink)
        if isinstance(node, list):
            return [walk(x) for x in node]
        if isinstance(node, dict):
            return {k: walk(v) for k, v in node.items()}
        return node

    return walk(container)


# --------------------------------------------------------------------------- #
# py evaluation (after standard interpolation)
# --------------------------------------------------------------------------- #
def _replace_token(node: Any, token: str, value: Any) -> Any:
    if isinstance(node, str):
        if node == token:
            return value  # whole-value -> keep native type
        return node.replace(token, str(value))
    if isinstance(node, list):
        return [_replace_token(x, token, value) for x in node]
    if isinstance(node, dict):
        return {k: _replace_token(v, token, value) for k, v in node.items()}
    return node


def _eval_pys(container: dict, exprs: list[str]) -> dict:
    tokens = [_SENTINEL.format(i) for i in range(len(exprs))]
    pending = set(range(len(exprs)))
    while pending:
        unresolved = {tokens[i] for i in pending}
        # namespace = top-level values that no longer contain unresolved tokens
        ns = {
            k: v
            for k, v in container.items()
            if not (isinstance(v, str) and any(t in v for t in unresolved))
        }
        progressed = False
        for i in sorted(pending):
            expr = exprs[i]
            if any(t in expr for t in unresolved if t != tokens[i]):
                continue  # depends on another unresolved py expr
            try:
                value = resolvers.eval_py(expr, ns)
            except resolvers.PyEvalError:
                continue  # likely references a not-yet-ready sibling; retry
            container = _replace_token(container, tokens[i], value)
            pending.discard(i)
            progressed = True
        if not progressed:
            stuck = ", ".join(f"${{py:{exprs[i]}}}" for i in sorted(pending))
            raise resolvers.PyEvalError(f"could not resolve: {stuck}")
    return container


# --------------------------------------------------------------------------- #
# public entry point
# --------------------------------------------------------------------------- #
def resolve_config(
    config: Any,
    *,
    overrides: Mapping[str, Any] | None = None,
    set_list: Iterable[str] | None = None,
    defaults_path: str | Path | None = None,
) -> dict:
    """Load + layer + fully resolve a config into a plain dict."""
    resolvers.register_resolvers()
    raw = load_merged_raw(
        config, overrides=overrides, set_list=set_list, defaults_path=defaults_path
    )

    exprs: list[str] = []
    protected = _protect_pys(raw, exprs)

    cfg = OmegaConf.create(protected)
    resolved = OmegaConf.to_container(cfg, resolve=True)

    if exprs:
        resolved = _eval_pys(resolved, exprs)
    return resolved
